#! /usr/bin/env python
#1. We have a tab delimited file with the columns which we want to extract

#Read in each line of the example file, split it into separate components, and write certain output to a separate file

#Set the input file name
#The program must be run from the directory that contains this data file
InFileName="Barcodes.tsv"

#Open the input file for reading ('r')
InFile = open(InFileName, 'r')

#initialize the counter used to keep track of line numbers
LineNumber = 0

#Open the output file for writing
#Do this *before* the loop, not inside it
#3 Write output to new file
OutFileName = InFileName + "list.txt"
#Give the option to write to a file or just print to screen
WriteOutFile = True
if WriteOutFile:
    #open the output file
    OutFile = open(OutFileName, 'w') #'w' for write; 'a' for append

#Loop through each line in the file
for Line in InFile:
    #skips header line 0
    if LineNumber > 0: 
        #Remove the line-ending characters
        Line = Line.strip('\n')

#2. Parse by using split() - produces a list of strings
        ElementList = Line.split('\t') #only splits data separated by tabs, preserves spaces within a string
        #Print the line
        #print LineNumber, ':', Line #modified to reflect the new ElementList
        #print LineNumber, ":", ElementList #- remove to check output
        #Returns:
        #96 : ['P1.2 - SbfI-TGCTCA ', '/5phos/', 'TGAGCA', 'AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT', '', '', '/5phos/TGAGCAAGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT']
        #       0                       1          2           3                               4   5   6            7
        
        Barcode = ElementList[0]
        #use the % operator to generate a string, can output both to screen and file
        ##OutputString = "Depth: %s\tLat: %s\tLon: %s" % (ElementList[4], ElementList[2], \
        ##                                       ElementList[3]) #backslash tells it to go to the next line of code as if it were the same line
        ##print OutputString
        OutString = "%s" % (Barcode)
        ##print OutString
        if WriteOutFile:
            OutFile.write(OutString+'\n')
        #Unline print statements, .write needs a linefeed
        ##OutFile.write(OutputString+'\n')
    #Index the counter used to keep track of line numbers
    LineNumber = LineNumber + 1
    
#After the loop is completed, close the file
InFile.close()
if WriteOutFile:
    OutFile.close()
