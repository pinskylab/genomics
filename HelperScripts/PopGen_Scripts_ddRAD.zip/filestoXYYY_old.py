#!/usr/bin/env python

#Everything between the triple quotations will print as to screen if the proprer arguments aren't given.
Usage = """
filestoXYYY.py - version 1.0
Example file for PCFB Chapter 11
Convert a series of X Y tab-delimited files
to X Y Y Y format and print them to the screen. 
Usage: 
	filestoXYYY.py *.txt > combinedfile.dat
"""

#import the sys module
import sys

#check for proper arguments
if len(sys.argv)<2:
	print Usage
else:
	FileList = sys.argv[1:]
#name the argument, for every argument on the command line...
	for InfileName in FileList:
	#print it to the screen
		print InfileName