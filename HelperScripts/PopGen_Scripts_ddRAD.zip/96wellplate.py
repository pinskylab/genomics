#!/usr/bin/env python
#to create a list of well labels for a 96 well plate

for Let in range(65,73): #steps through characters A-H
    for Num in range(1,13): #steps through numbers 1-12
        print chr(Let) + str(Num), #comma makes table format
    print #second print makes line break after every Let is complete
#chr returns the ASCII character assigned to that number A=65 a=97.