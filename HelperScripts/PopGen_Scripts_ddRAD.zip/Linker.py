#!/usr/bin/env python

#A code to Add a barcode to the front of a sequence

GeneList= ['ATTCAGAAT','TGTGAAAGT','TGTATCGCG','ATGTCTCTA']
FirstCodons= [ Seq[0:3] for Seq in GeneList]
print FirstCodons

#add linker to just the first 3 codons
Linker='GAATTC'
Start = [(Linker + Seq[0:3]) for Seq in GeneList]
print Start