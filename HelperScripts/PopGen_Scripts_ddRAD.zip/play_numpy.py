#! /usr/bin/env python

from numpy import *

MyArray = array ([[1,2,3],[4,5,6],[7,8,9]]) #create a 2-D table of numbers

print MyArray

MyRow = MyArray[1,:] #second row, all columns

print MyRow

MyColumn = MyArray[:,1] #second column all rows

print MyColumn

print MyArray[:2,:2]

V = [1,1,3,5,6]

print "The median is", median(V)

print "The mean is" , mean(V)

print "The max is",max(V) 

print "The min is",min(V)
